package zako.bowspam;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class BowSpamClient implements ClientModInitializer {
    // Минимум тиков натяжения, при котором выстрел вообще возможен (прогресс >= 0.1 -> 3 тика).
    // Если стрелы иногда не вылетают из-за пинга, поставь 4 или 5.
    private static final int MIN_CHARGE_TICKS = 3;

    private static boolean enabled = false;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bowspam.toggle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H, "category.bowspam"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(
                            "BowSpam: " + (enabled ? "ON" : "OFF")), true);
                }
            }
            tick(client);
        });
    }

    private static void tick(MinecraftClient client) {
        if (!enabled || client.player == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        if (!client.player.getMainHandStack().isOf(Items.BOW)) return;
        // работает только пока зажата ПКМ
        if (!client.options.useKey.isPressed()) return;

        if (client.player.isUsingItem()) {
            if (client.player.getItemUseTime() >= MIN_CHARGE_TICKS) {
                client.interactionManager.stopUsingItem(client.player);
            }
        } else {
            client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
        }
    }
}
